<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="id-ID">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="id-ID">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log Masuk &lsaquo; Dokari Tranz Travel &#8212; WordPress</title>
		<script type="text/javascript">function theChampLoadEvent(e){var t=window.onload;if(typeof window.onload!="function"){window.onload=e}else{window.onload=function(){t();e()}}}</script>
		<script type="text/javascript">var theChampDefaultLang = 'id_ID', theChampCloseIconPath = 'http://dokari.co.id/wp-content/plugins/super-socializer/images/close.png';</script>
		<script> var theChampSiteUrl = 'http://dokari.co.id', theChampVerified = 0, theChampEmailPopup = 0; </script>
			<script> var theChampSharingAjaxUrl = 'http://dokari.co.id/wp-admin/admin-ajax.php', heateorSsWhatsappShareAPI = 'web', heateorSsUrlCountFetched = [], heateorSsSharesText = 'Shares', heateorSsShareText = 'Share', theChampPluginIconPath = 'http://dokari.co.id/wp-content/plugins/super-socializer/images/logo.png', theChampHorizontalSharingCountEnable = 0, theChampVerticalSharingCountEnable = 0, theChampSharingOffset = -10, theChampCounterOffset = -10, theChampMobileStickySharingEnabled = 1, heateorSsCopyLinkMessage = "Link copied.";
		var heateorSsHorSharingShortUrl = "http://dokari.co.id/wp-login.php";var heateorSsVerticalSharingShortUrl = "http://dokari.co.id";		</script>
			<style type="text/css">.the_champ_horizontal_sharing .theChampSharing{
					color: #fff;
				border-width: 0px;
		border-style: solid;
		border-color: transparent;
	}
		.the_champ_horizontal_sharing .theChampTCBackground{
		color:#666;
	}
		.the_champ_horizontal_sharing .theChampSharing:hover{
				border-color: transparent;
	}
	.the_champ_vertical_sharing .theChampSharing{
					color: #fff;
				border-width: 0px;
		border-style: solid;
		border-color: transparent;
	}
		.the_champ_vertical_sharing .theChampTCBackground{
		color:#666;
	}
		.the_champ_vertical_sharing .theChampSharing:hover{
				border-color: transparent;
	}
	@media screen and (max-width:783px){.the_champ_vertical_sharing{display:none!important}}div.heateor_ss_mobile_footer{display:none;}@media screen and (max-width:783px){div.the_champ_bottom_sharing{width:100%!important;left:0!important;}div.the_champ_bottom_sharing li{width:10% !important;}div.the_champ_bottom_sharing .theChampSharing{width: 100% !important;}div.the_champ_bottom_sharing div.theChampTotalShareCount{font-size:1em!important;line-height:28px!important}div.the_champ_bottom_sharing div.theChampTotalShareText{font-size:.7em!important;line-height:0px!important}div.heateor_ss_mobile_footer{display:block;height:40px;}.the_champ_bottom_sharing{padding:0!important;display:block!important;width: auto!important;bottom:-2px!important;top: auto!important;}.the_champ_bottom_sharing .the_champ_square_count{line-height: inherit;}.the_champ_bottom_sharing .theChampSharingArrow{display:none;}.the_champ_bottom_sharing .theChampTCBackground{margin-right: 1.1em !important}}div.the_champ_sharing_title{text-align:center}ul.the_champ_sharing_ul{width:100%;text-align:center;}div.the_champ_horizontal_sharing ul.the_champ_sharing_ul li{float:none!important;display:inline-block;}</style>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='http://dokari.co.id/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://dokari.co.id/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='stylesheet' id='dashicons-css'  href='http://dokari.co.id/wp-includes/css/dashicons.min.css?ver=5.1.2' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='http://dokari.co.id/wp-includes/css/buttons.min.css?ver=5.1.2' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='http://dokari.co.id/wp-admin/css/forms.min.css?ver=5.1.2' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='http://dokari.co.id/wp-admin/css/l10n.min.css?ver=5.1.2' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='http://dokari.co.id/wp-admin/css/login.min.css?ver=5.1.2' type='text/css' media='all' />
<link rel='stylesheet' id='the_champ_frontend_css-css'  href='http://dokari.co.id/wp-content/plugins/super-socializer/css/front.css?ver=7.12.15' type='text/css' media='all' />
<link rel='stylesheet' id='the_champ_sharing_default_svg-css'  href='http://dokari.co.id/wp-content/plugins/super-socializer/css/share-svg.css?ver=7.12.15' type='text/css' media='all' />
	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-id-id">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Diberdayakan dengan WordPress">Diberdayakan dengan WordPress</a></h1>
	
	<form name="loginform" id="loginform" action="http://dokari.co.id/wp-login.php" method="post">
	<p>
		<label for="user_login">Nama Pengguna atau Alamat Email<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" /></label>
	</p>
	<p>
		<label for="user_pass">Sandi<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
			<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Ingat Saya</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log Masuk" />
				<input type="hidden" name="redirect_to" value="http://dokari.co.id/wp-admin/" />
					<input type="hidden" name="testcookie" value="1" />
	</p>
	</form>

			<p id="nav">
					<a href="http://dokari.co.id/wp-login.php?action=lostpassword">Lupa sandi Anda?</a>
				</p>
	
	<script type="text/javascript">
	function wp_attempt_focus(){
	setTimeout( function(){ try{
			d = document.getElementById('user_login');
				d.focus();
	d.select();
	} catch(e){}
	}, 200);
	}

			wp_attempt_focus();
			if(typeof wpOnload=='function')wpOnload();
			</script>

			<p id="backtoblog"><a href="http://dokari.co.id/">
		&larr; Kembali ke Dokari Tranz Travel	</a></p>
			
	</div>

	
	<script type='text/javascript' src='http://dokari.co.id/wp-content/plugins/super-socializer/js/front/combined.js?ver=7.12.15'></script>
	<div class="clear"></div>
	</body>
	</html>
	